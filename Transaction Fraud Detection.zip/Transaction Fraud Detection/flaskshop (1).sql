-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 30, 2024 at 12:02 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flaskshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_address`
--

CREATE TABLE `account_address` (
  `user_id` int(11) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_name` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(80) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_address`
--

INSERT INTO `account_address` (`user_id`, `province`, `city`, `district`, `address`, `contact_name`, `contact_phone`, `id`, `created_at`, `updated_at`) VALUES
(1, 'Texas', 'Port Danielborough', 'port', '097 Buck Light Apt. 429', 'Nicholas Jones', '+1-941-597-9622', 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 'Arkansas', 'Marktown', 'mouth', '632 Lisa Island', 'Gavin Watts', '326-509-1434', 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(3, 'Idaho', 'Tanyaview', 'view', '7035 Ruiz Pike Suite 349', 'Emma Newton', '2819580578', 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 'Nevada', 'Kaiserville', 'bury', '69531 Simpson Fords Apt. 400', 'Leroy Jennings', '821.911.3123x80014', 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(5, 'Rhode Island', 'Lake Brettville', 'borough', '759 Burton Court Suite 921', 'Breanna George', '244-235-7548x94773', 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(6, 'Rhode Island', 'Buckborough', 'fort', '29872 Osborn Causeway', 'Emily Benton', '(344)782-0450', 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(7, 'Minnesota', 'Carterville', 'shire', '1963 Rachel River Apt. 276', 'Heidi Martin', '557.333.8451x155', 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(8, 'Delaware', 'South Gwendolynbury', 'mouth', '99203 Jack Springs', 'Patricia Hunt', '815-845-4068x30682', 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(9, 'Michigan', 'Gregoryton', 'berg', '269 Justin Extension', 'Matthew Trevino', '001-266-917-8823', 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(10, 'New Hampshire', 'East Joshuaview', 'town', '4377 Amanda Plains', 'Kirk Wilson', '(760)202-0380x348', 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(11, 'Georgia', 'Robertside', 'burgh', '088 Carpenter Landing', 'Pamela Miller', '+1-662-486-3413x2827', 11, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(11, 'Iowa', 'Amyview', 'view', '2299 Elizabeth Highway Suite 232', 'Chad Pierce', '755-353-3670x73261', 12, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(11, 'Maryland', 'Port Donna', 'mouth', '17160 Richard Turnpike Suite 848', 'Sara Brown', '+1-643-885-2399x7414', 13, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(NULL, 'Michigan', 'Kellyland', 'haven', '8773 Betty Wells Suite 399', 'Angie Houston', '(549)994-3146x161', 14, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(NULL, 'New York', 'South Davidburgh', 'burgh', '1521 Smith Crest Suite 640', 'James Mercer', '(230)817-3148x22579', 15, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(NULL, 'Michigan', 'Robertfort', 'view', '95450 Brenda Flats Apt. 219', 'Jason Baker', '(254)750-0345', 16, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(NULL, 'Florida', 'Bauerberg', 'stad', '813 Jared Unions', 'Charles Perkins', '752.651.8011', 17, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(NULL, 'Missouri', 'Brandymouth', 'land', '9360 Young Station Apt. 123', 'Robert Miller', '(514)810-0565', 18, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(NULL, 'Minnesota', 'New Lucasborough', 'borough', '57773 Silva View', 'Christopher Robinson', '(587)208-3509', 19, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(NULL, 'Utah', 'Harmonbury', 'land', '09671 Heath Turnpike Apt. 250', 'Patrick Cherry', '651-385-8182x03932', 20, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(NULL, 'New Hampshire', 'West Richard', 'port', '2929 Briana Route', 'Mrs. Lisa Lopez', '617.859.8861x8800', 21, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(NULL, 'Wyoming', 'Hernandezview', 'side', '103 Susan Brooks', 'Michelle Hughes', '400-786-7818', 22, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(NULL, 'Alaska', 'New Christopher', 'port', '3060 Rivers Grove', 'Teresa Vargas', '(584)545-6291x030', 23, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(14, 'Karnataka', 'Davangere', 'Davanagere', 'Kandagal', 'Nasir ahamad K C', '08951195736', 24, '2024-06-23 16:31:58', '2024-06-23 16:31:58'),
(15, 'Karnataka', 'Davangere', 'Davanagere', 'Kandagal', 'Nasir ahamad K C', '08951195736', 25, '2024-06-30 08:55:51', '2024-06-30 08:55:51');

-- --------------------------------------------------------

--
-- Table structure for table `account_role`
--

CREATE TABLE `account_role` (
  `name` varchar(80) DEFAULT NULL,
  `permissions` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_role`
--

INSERT INTO `account_role` (`name`, `permissions`, `id`, `created_at`, `updated_at`) VALUES
('login', 1, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('editor', 2, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('op', 4, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('admin', 255, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `account_user`
--

CREATE TABLE `account_user` (
  `username` varchar(80) NOT NULL COMMENT 'user`s name',
  `email` varchar(80) NOT NULL,
  `_password` varchar(255) NOT NULL,
  `nick_name` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `open_id` varchar(80) DEFAULT NULL,
  `session_key` varchar(80) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_user`
--

INSERT INTO `account_user` (`username`, `email`, `_password`, `nick_name`, `is_active`, `open_id`, `session_key`, `id`, `created_at`, `updated_at`) VALUES
('TiffanyPage', 'andrew.mann@example.com', '$2b$13$vaV0zxYckVFS7/E8I0wxjukUuyLxCuY6eN21fwvidzNresWt9koTK', NULL, 1, NULL, NULL, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('CrystalMckinney', 'troy.fuller@example.com', '$2b$13$wT5cUcStXImTcf9v8U0Sf.p1jaUfguTdOxu5Bq6YcogB8mdDwqSQO', NULL, 1, NULL, NULL, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('MorganChang', 'carolyn.mcdonald@example.com', '$2b$13$CJ8sTV9TyGCW8Kqu.7mpMONQWqiv6nfMvgChFcnsQlZmVUXvnyrNi', NULL, 1, NULL, NULL, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('MaryLarsen', 'kelly.lowery@example.com', '$2b$13$aGbY/7VgRNbJtd2iSZNcGeeMibI440HJ6XOjMIGGrljXAWa3ER/GK', NULL, 1, NULL, NULL, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('LindseyOrtiz', 'tonya.robinson@example.com', '$2b$13$XiymfRf1ZZ6vshQa.HxcwuyiIzDRe/h9uO3ftme4IEruCT.4dqfjW', NULL, 1, NULL, NULL, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('MichaelWest', 'richard.young@example.com', '$2b$13$8USBAGXcaE762Bk2GdO5dOiKpNhTNJ9a9v3xTdwN4g6ru/B.Wjn0K', NULL, 1, NULL, NULL, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('SueBridges', 'stephen.riley@example.com', '$2b$13$INBm.IZ3M1bkuLYXb/8y1unAzLKXBwY84D3z.rJ2UBlTfiYnfhtkS', NULL, 1, NULL, NULL, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('AnneStewart', 'jennifer.rios@example.com', '$2b$13$Gd2UeGcdoH1WLbgBxPo7huFfq0uw4mP4mOmc.gFcp.9zrIMkJvsZS', NULL, 1, NULL, NULL, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('BenjaminWhitehead', 'shannon.craig@example.com', '$2b$13$fc71P.iJZVSZzTrR0lrMFOsVjHCJ8oIDYbWpMvfkgkSAhUbH1PfOu', NULL, 1, NULL, NULL, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('ErinAlvarado', 'gerald.alexander@example.com', '$2b$13$xyQ80PhWXb3yqZC4KDDowOdEAcjVCdpKtLguHpuSj1PXZChvzC9QS', NULL, 1, NULL, NULL, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('admin', 'admin@163.com', '$2b$13$HdH28pyfcLc5r7hge2XfTOfPbYixCa8pSIxtStTVxmFiuEydsFhsi', NULL, 1, NULL, NULL, 11, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('op', 'op@163.com', '$2b$13$OJgj8x2BRhFfN7thbqM6PeWk0q2A.fEKHC5yj2Y1wDr4U6OC3/Ca.', NULL, 1, NULL, NULL, 12, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('editor', 'editor@163.com', '$2b$13$aD8qM./kQ4OQwHbtFv6sF.hqP85bOVStyjGzBh/LuiRNw7MPoEF2K', NULL, 1, NULL, NULL, 13, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('nasir', 'n@gmail.com', '$2b$13$oyZ9yP5.OsIpTD3Vl/HOjui252BL7I0lr9y2zwyCcF/YMZ6lRXR/C', NULL, 1, NULL, NULL, 14, '2024-06-23 16:31:58', '2024-06-23 16:31:58'),
('nasirs', 'na2507669@gmail.com', '$2b$13$FB.K0Q8UcyfeKGi1vkf9y.P2liaqzky8B5sg6yZDlMISPyfsRUyTW', NULL, 1, NULL, NULL, 15, '2024-06-30 08:55:51', '2024-06-30 08:55:51');

-- --------------------------------------------------------

--
-- Table structure for table `account_user_role`
--

CREATE TABLE `account_user_role` (
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_user_role`
--

INSERT INTO `account_user_role` (`user_id`, `role_id`, `id`, `created_at`, `updated_at`) VALUES
(11, 4, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(12, 3, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(13, 2, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `checkout_cart`
--

CREATE TABLE `checkout_cart` (
  `user_id` int(11) DEFAULT NULL,
  `voucher_code` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `shipping_address_id` int(11) DEFAULT NULL,
  `shipping_method_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `checkout_cartline`
--

CREATE TABLE `checkout_cartline` (
  `cart_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `checkout_shippingmethod`
--

CREATE TABLE `checkout_shippingmethod` (
  `title` varchar(255) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkout_shippingmethod`
--

INSERT INTO `checkout_shippingmethod` (`title`, `price`, `id`, `created_at`, `updated_at`) VALUES
('UPC', 99.35, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('DHL', 53.73, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `discount_sale`
--

CREATE TABLE `discount_sale` (
  `discount_value_type` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `discount_value` decimal(10,2) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `discount_sale`
--

INSERT INTO `discount_sale` (`discount_value_type`, `title`, `discount_value`, `id`, `created_at`, `updated_at`) VALUES
(2, 'Happy happen day!', 30.00, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 'Happy big day!', 50.00, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 'Happy hundred day!', 40.00, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 'Happy fill day!', 30.00, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 'Happy address day!', 10.00, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `discount_sale_category`
--

CREATE TABLE `discount_sale_category` (
  `sale_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `discount_sale_product`
--

CREATE TABLE `discount_sale_product` (
  `sale_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `discount_sale_product`
--

INSERT INTO `discount_sale_product` (`sale_id`, `product_id`, `id`, `created_at`, `updated_at`) VALUES
(1, 16, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(1, 49, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(1, 44, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(1, 35, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 31, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 41, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 5, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 18, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(3, 30, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(3, 9, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(3, 1, 11, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(3, 59, 12, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 18, 13, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 43, 14, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 37, 15, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 2, 16, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(5, 35, 17, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(5, 18, 18, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(5, 49, 19, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(5, 36, 20, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `discount_voucher`
--

CREATE TABLE `discount_voucher` (
  `type` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `code` varchar(16) DEFAULT NULL,
  `usage_limit` int(11) DEFAULT NULL,
  `used` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `discount_value_type` int(11) DEFAULT NULL,
  `discount_value` decimal(10,2) DEFAULT NULL,
  `limit` decimal(10,2) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `discount_voucher`
--

INSERT INTO `discount_voucher` (`type`, `title`, `code`, `usage_limit`, `used`, `start_date`, `end_date`, `discount_value_type`, `discount_value`, `limit`, `category_id`, `product_id`, `id`, `created_at`, `updated_at`) VALUES
(3, 'Free shipping', 'FREESHIPPING', NULL, 0, NULL, NULL, 2, 100.00, NULL, NULL, NULL, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 'Big order discount', 'DISCOUNT', NULL, 0, NULL, NULL, 1, 25.00, 200.00, NULL, NULL, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `management_dashboard`
--

CREATE TABLE `management_dashboard` (
  `title` varchar(255) NOT NULL,
  `order` int(11) DEFAULT NULL,
  `endpoint` varchar(255) DEFAULT NULL,
  `icon_cls` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `management_dashboard`
--

INSERT INTO `management_dashboard` (`title`, `order`, `endpoint`, `icon_cls`, `parent_id`, `id`, `created_at`, `updated_at`) VALUES
('CATALOG', 0, NULL, 'fa-bandcamp', 0, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('ORDERS', 0, 'orders', 'fa-cart-arrow-down', 0, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('CUSTOMERS', 0, 'users', 'fa-user', 0, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('CONFIGURATION', 0, 'config_index', 'fa-cog', 0, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Products', 0, 'products', NULL, 1, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Categories', 0, 'categories', NULL, 1, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Collections', 0, 'collections', NULL, 1, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Sales', 0, 'sales', NULL, 4, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Vouchers', 0, 'vouchers', NULL, 4, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `management_setting`
--

CREATE TABLE `management_setting` (
  `key` varchar(255) NOT NULL,
  `value` blob NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `value_type` enum('string','integer','float','boolean','select','selectmultiple') NOT NULL,
  `extra` blob DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `management_setting`
--

INSERT INTO `management_setting` (`key`, `value`, `name`, `description`, `value_type`, `extra`, `created_at`, `updated_at`) VALUES
('project_copyright', 0x80059515000000000000008c11434f5059524947485420c2a92032303234942e, 'Project Copyright', 'Copyright notice of the Project like \'&copy; 2019 FlaskShop\'. ', 'string', NULL, '2024-06-23 16:28:35', '2024-06-30 09:31:40'),
('project_subtitle', 0x8005951f000000000000008c1b437265646974206361726420667261756420646574656374696f6e942e, 'Project subtitle', 'A short description of the project.', 'string', NULL, '2024-06-23 16:28:35', '2024-06-30 09:31:40'),
('project_title', 0x8005951f000000000000008c1b437265646974206361726420667261756420646574656374696f6e942e, 'Project title', 'The title of the project.', 'string', NULL, '2024-06-23 16:28:35', '2024-06-30 09:31:40');

-- --------------------------------------------------------

--
-- Table structure for table `order_event`
--

CREATE TABLE `order_event` (
  `order_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_event`
--

INSERT INTO `order_event` (`order_id`, `user_id`, `type`, `id`, `created_at`, `updated_at`) VALUES
(15, 11, 2, 1, '2024-06-23 17:52:44', '2024-06-23 17:52:44'),
(16, 11, 2, 2, '2024-06-23 17:52:44', '2024-06-23 17:52:44'),
(17, 15, 4, 3, '2024-06-30 08:55:51', '2024-06-30 08:55:51'),
(17, 15, 4, 4, '2024-06-30 08:55:51', '2024-06-30 08:55:51'),
(17, 15, 4, 5, '2024-06-30 08:55:51', '2024-06-30 08:55:51');

-- --------------------------------------------------------

--
-- Table structure for table `order_line`
--

CREATE TABLE `order_line` (
  `product_name` varchar(255) DEFAULT NULL,
  `product_sku` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `unit_price_net` decimal(10,2) DEFAULT NULL,
  `is_shipping_required` tinyint(1) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_line`
--

INSERT INTO `order_line` (`product_name`, `product_sku`, `quantity`, `unit_price_net`, `is_shipping_required`, `order_id`, `variant_id`, `product_id`, `id`, `created_at`, `updated_at`) VALUES
('Holland and Sons (13-83052)', '13-83052', 1, 15.31, 1, 1, 63, 13, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Shepherd-Contreras (100g)', '35-1337', 2, 91.88, 1, 1, 123, 35, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Elliott Inc (15-29905)', '15-29905', 1, 2.67, 1, 1, 65, 15, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Russell-Ramirez (100g)', '33-1337', 4, 27.92, 1, 2, 117, 33, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Crawford LLC (100g)', '39-1337', 4, 41.64, 1, 2, 135, 39, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Gomez, Moody and Mason (XS)', '7-1337', 3, 29.56, 1, 2, 37, 7, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Rios PLC (41-94459)', '41-94459', 3, 74.44, 0, 2, 141, 41, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Perry LLC (XS)', '10-1337', 4, 51.44, 1, 3, 55, 10, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Williams-Nash (XS)', '9-1337', 2, 3.49, 1, 3, 49, 9, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Gibson Group (Soft)', '52-1337', 3, 53.96, 1, 4, 153, 52, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Bennett Group (Soft)', '57-1337', 4, 87.02, 1, 5, 163, 57, 11, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Fisher, Lane and Dawson (100g)', '26-1337', 1, 116.32, 1, 5, 91, 26, 12, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Johns PLC (XS)', '3-1337', 2, 29.44, 1, 6, 13, 3, 13, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Burns, Lee and Kennedy (100g)', '27-1337', 2, 116.63, 1, 6, 95, 27, 14, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Castillo Group (100g)', '32-1337', 1, 79.83, 1, 6, 114, 32, 15, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Porter-Nicholson (100g)', '34-1337', 2, 26.87, 1, 7, 120, 34, 16, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Russell-Ramirez (100g)', '33-1337', 3, 27.92, 1, 8, 117, 33, 17, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Castillo Group (100g)', '32-1337', 2, 79.83, 1, 8, 114, 32, 18, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Welch and Sons (100g)', '31-1337', 1, 47.81, 1, 9, 111, 31, 19, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Morris, Welch and Obrien (Soft)', '59-1337', 4, 81.79, 1, 9, 167, 59, 20, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Foster Inc (50-78902)', '50-78902', 2, 74.29, 0, 9, 150, 50, 21, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Tran LLC (100g)', '38-1337', 2, 52.85, 1, 9, 132, 38, 22, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Morris, Welch and Obrien (Soft)', '59-1337', 1, 81.79, 1, 10, 167, 59, 23, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Porter-Nicholson (100g)', '34-1337', 3, 26.87, 1, 10, 120, 34, 24, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Miller Group (XS)', '5-1337', 1, 31.52, 1, 11, 25, 5, 25, '2024-06-23 16:31:58', '2024-06-23 16:31:58'),
('Elliott Inc (15-29905)', '15-29905', 1, 2.67, 1, 12, 65, 15, 26, '2024-06-23 16:31:58', '2024-06-23 16:31:58'),
('Williams-Nash (XS)', '9-1337', 1, 2.09, 1, 13, 49, 9, 27, '2024-06-23 16:31:58', '2024-06-23 16:31:58'),
('Williams-Nash (XS)', '9-1337', 1, 2.09, 1, 14, 49, 9, 28, '2024-06-23 17:00:02', '2024-06-23 17:00:02'),
('Benitez Ltd (XS)', '2-1337', 1, 33.38, 1, 15, 7, 2, 29, '2024-06-23 17:22:22', '2024-06-23 17:22:22'),
('Miller Group (XS)', '5-1337', 1, 31.52, 1, 16, 25, 5, 30, '2024-06-23 17:52:44', '2024-06-23 17:52:44'),
('Miller Group (XS)', '5-1337', 1, 31.52, 1, 17, 25, 5, 31, '2024-06-30 08:55:51', '2024-06-30 08:55:51'),
('Miller Group (XS)', '5-1337', 1, 31.52, 1, 18, 25, 5, 32, '2024-06-30 09:12:23', '2024-06-30 09:12:23'),
('Johns PLC (XS)', '3-1337', 1, 29.44, 1, 19, 13, 3, 33, '2024-06-30 09:16:24', '2024-06-30 09:16:24'),
('Miller Group (XS)', '5-1337', 2, 31.52, 1, 20, 25, 5, 34, '2024-06-30 09:19:05', '2024-06-30 09:19:05'),
('Elliott Inc (15-29905)', '15-29905', 1, 2.67, 1, 21, 65, 15, 35, '2024-06-30 09:51:55', '2024-06-30 09:51:55');

-- --------------------------------------------------------

--
-- Table structure for table `order_note`
--

CREATE TABLE `order_note` (
  `order_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_note`
--

INSERT INTO `order_note` (`order_id`, `user_id`, `content`, `is_public`, `id`, `created_at`, `updated_at`) VALUES
(11, 14, 'df', 1, 1, '2024-06-23 16:31:58', '2024-06-23 16:31:58'),
(13, 11, 'xx', 1, 2, '2024-06-23 16:31:58', '2024-06-23 16:31:58'),
(14, 11, 'zz', 1, 3, '2024-06-23 17:00:02', '2024-06-23 17:00:02'),
(15, 11, 'd', 1, 4, '2024-06-23 17:22:22', '2024-06-23 17:22:22'),
(16, 11, 'ss', 1, 5, '2024-06-23 17:52:44', '2024-06-23 17:52:44'),
(17, 15, 'dfg', 1, 6, '2024-06-30 08:55:51', '2024-06-30 08:55:51'),
(19, 15, 'c', 1, 7, '2024-06-30 09:16:24', '2024-06-30 09:16:24'),
(20, 15, '66', 1, 8, '2024-06-30 09:19:05', '2024-06-30 09:19:05');

-- --------------------------------------------------------

--
-- Table structure for table `order_order`
--

CREATE TABLE `order_order` (
  `token` varchar(100) DEFAULT NULL,
  `shipping_address` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total_net` decimal(10,2) DEFAULT NULL,
  `discount_amount` decimal(10,2) DEFAULT NULL,
  `discount_name` varchar(100) DEFAULT NULL,
  `voucher_id` int(11) DEFAULT NULL,
  `shipping_price_net` decimal(10,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `shipping_method_name` varchar(100) DEFAULT NULL,
  `shipping_method_id` int(11) DEFAULT NULL,
  `ship_status` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_order`
--

INSERT INTO `order_order` (`token`, `shipping_address`, `user_id`, `total_net`, `discount_amount`, `discount_name`, `voucher_id`, `shipping_price_net`, `status`, `shipping_method_name`, `shipping_method_id`, `ship_status`, `id`, `created_at`, `updated_at`) VALUES
('394c9979-e5b5-413c-a5a1-e0525fa475fc', 'Michigan<br>Kellyland<br>haven<br>8773 Betty Wells Suite 399<br>Angie Houston<br>(549)994-3146x161', 4, 201.74, 0.00, NULL, NULL, 53.73, 4, 'DHL', 2, NULL, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('6538d556-5623-4cee-b127-978681c6b746', 'New York<br>South Davidburgh<br>burgh<br>1521 Smith Crest Suite 640<br>James Mercer<br>(230)817-3148x22579', 4, 590.24, 0.00, NULL, NULL, 53.73, 5, 'DHL', 2, NULL, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('a3271e83-f639-45b2-94c6-f90f4736a8c6', 'Michigan<br>Robertfort<br>view<br>95450 Brenda Flats Apt. 219<br>Jason Baker<br>(254)750-0345', 2, 212.74, 0.00, NULL, NULL, 99.35, 6, 'UPC', 1, NULL, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('8fb371d8-344f-40aa-9c85-5184b42afbec', 'Florida<br>Bauerberg<br>stad<br>813 Jared Unions<br>Charles Perkins<br>752.651.8011', 1, 161.88, 0.00, NULL, NULL, 99.35, 1, 'UPC', 1, NULL, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('738d8093-3a0d-4275-ae0a-fac91cd2b662', 'Missouri<br>Brandymouth<br>land<br>9360 Young Station Apt. 123<br>Robert Miller<br>(514)810-0565', 11, 464.40, 0.00, NULL, NULL, 53.73, 1, 'DHL', 2, NULL, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('f274f7f8-19bc-4b2c-911d-25df544b1471', 'Minnesota<br>New Lucasborough<br>borough<br>57773 Silva View<br>Christopher Robinson<br>(587)208-3509', 5, 371.97, 0.00, NULL, NULL, 99.35, 5, 'UPC', 1, NULL, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('bb9008b6-2cae-45e0-a9ca-1ed69d84c227', 'Utah<br>Harmonbury<br>land<br>09671 Heath Turnpike Apt. 250<br>Patrick Cherry<br>651-385-8182x03932', 4, 53.74, 0.00, NULL, NULL, 53.73, 4, 'DHL', 2, NULL, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('d7540052-a491-4ef8-88b6-755689ee780b', 'New Hampshire<br>West Richard<br>port<br>2929 Briana Route<br>Mrs. Lisa Lopez<br>617.859.8861x8800', 12, 243.42, 0.00, NULL, NULL, 99.35, 6, 'UPC', 1, NULL, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('c2f1123f-40a0-4975-92ca-f33d3e321ffe', 'Wyoming<br>Hernandezview<br>side<br>103 Susan Brooks<br>Michelle Hughes<br>400-786-7818', 7, 629.25, 0.00, NULL, NULL, 99.35, 6, 'UPC', 1, NULL, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('a89ff9d5-63aa-4691-bcc6-3761e642677d', 'Alaska<br>New Christopher<br>port<br>3060 Rivers Grove<br>Teresa Vargas<br>(584)545-6291x030', 12, 162.40, 0.00, NULL, NULL, 99.35, 2, 'UPC', 1, NULL, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('46341d1c-3598-4b1f-9e42-a612cf0c4cc7', 'Karnataka<br>Davangere<br>Davanagere<br>Kandagal<br>Nasir ahamad K C<br>08951195736', 14, 31.52, 0.00, NULL, NULL, 53.73, 2, 'DHL', 2, NULL, 11, '2024-06-23 16:31:58', '2024-06-23 16:31:58'),
('f6036466-28f4-4773-b394-6e73d49b96b0', 'Georgia<br>Robertside<br>burgh<br>088 Carpenter Landing<br>Pamela Miller<br>+1-662-486-3413x2827', 11, 2.67, 0.00, NULL, NULL, 99.35, 2, 'UPC', 1, NULL, 12, '2024-06-23 16:31:58', '2024-06-23 16:31:58'),
('5a8430a2-820f-43d8-8fdf-950f8d4c12fd', 'Georgia<br>Robertside<br>burgh<br>088 Carpenter Landing<br>Pamela Miller<br>+1-662-486-3413x2827', 11, 2.09, 0.00, NULL, NULL, 99.35, 2, 'UPC', 1, NULL, 13, '2024-06-23 16:31:58', '2024-06-23 16:31:58'),
('bc33f3a0-82f2-4ff6-8eb2-5bfc979ec50e', 'Georgia<br>Robertside<br>burgh<br>088 Carpenter Landing<br>Pamela Miller<br>+1-662-486-3413x2827', 11, 2.09, 0.00, NULL, NULL, 99.35, 2, 'UPC', 1, NULL, 14, '2024-06-23 17:00:02', '2024-06-23 17:00:02'),
('7003a7ed-b82d-448c-845f-3e3c12732a9f', 'Georgia<br>Robertside<br>burgh<br>088 Carpenter Landing<br>Pamela Miller<br>+1-662-486-3413x2827', 11, 33.38, 0.00, NULL, NULL, 99.35, 3, 'UPC', 1, NULL, 15, '2024-06-23 17:22:22', '2024-06-23 17:52:44'),
('2d4fd9bf-3434-4599-92f5-46eff69a0fbc', 'Georgia<br>Robertside<br>burgh<br>088 Carpenter Landing<br>Pamela Miller<br>+1-662-486-3413x2827', 11, 31.52, 0.00, NULL, NULL, 99.35, 3, 'UPC', 1, NULL, 16, '2024-06-23 17:52:44', '2024-06-23 17:52:44'),
('0d25ade2-80b9-49f0-a7fd-8c921bbb8ed1', 'Karnataka<br>Davangere<br>Davanagere<br>Kandagal<br>Nasir ahamad K C<br>08951195736', 15, 31.52, 0.00, NULL, NULL, 53.73, 4, 'DHL', 2, NULL, 17, '2024-06-30 08:55:51', '2024-06-30 08:55:51'),
('7ff6febf-253b-47f5-931e-7320ece9060e', 'Karnataka<br>Davangere<br>Davanagere<br>Kandagal<br>Nasir ahamad K C<br>08951195736', 15, 31.52, 0.00, NULL, NULL, 99.35, 2, 'UPC', 1, NULL, 18, '2024-06-30 09:12:23', '2024-06-30 09:12:23'),
('9aba86a7-88a7-4f43-a765-645855cd2669', 'Karnataka<br>Davangere<br>Davanagere<br>Kandagal<br>Nasir ahamad K C<br>08951195736', 15, 29.44, 0.00, NULL, NULL, 99.35, 2, 'UPC', 1, NULL, 19, '2024-06-30 09:16:24', '2024-06-30 09:16:24'),
('b928d268-4759-41b0-b24e-4b7991e307dd', 'Karnataka<br>Davangere<br>Davanagere<br>Kandagal<br>Nasir ahamad K C<br>08951195736', 15, 63.04, 0.00, NULL, NULL, 99.35, 2, 'UPC', 1, NULL, 20, '2024-06-30 09:19:05', '2024-06-30 09:19:05'),
('08580f7f-e211-4961-a75f-7ceb66791b7f', 'Karnataka<br>Davangere<br>Davanagere<br>Kandagal<br>Nasir ahamad K C<br>08951195736', 15, 2.67, 0.00, NULL, NULL, 99.35, 2, 'UPC', 1, NULL, 21, '2024-06-30 09:51:55', '2024-06-30 09:51:55');

-- --------------------------------------------------------

--
-- Table structure for table `order_payment`
--

CREATE TABLE `order_payment` (
  `order_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `delivery` decimal(10,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `customer_ip_address` varchar(100) DEFAULT NULL,
  `token` varchar(100) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `payment_no` varchar(255) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_payment`
--

INSERT INTO `order_payment` (`order_id`, `status`, `total`, `delivery`, `description`, `customer_ip_address`, `token`, `payment_method`, `payment_no`, `paid_at`, `id`, `created_at`, `updated_at`) VALUES
(1, 2, 201.74, 53.73, NULL, '5.250.189.32', NULL, NULL, NULL, NULL, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 2, 590.24, 53.73, NULL, '62.197.4.109', NULL, NULL, NULL, NULL, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(3, 4, 212.74, 99.35, NULL, '90.125.146.200', NULL, NULL, NULL, NULL, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 2, 161.88, 99.35, NULL, '27.21.116.58', NULL, NULL, NULL, NULL, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(5, 1, 464.40, 53.73, NULL, '113.34.102.175', NULL, NULL, NULL, NULL, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(6, 2, 371.97, 99.35, NULL, '92.45.250.35', NULL, NULL, NULL, NULL, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(7, 2, 53.74, 53.73, NULL, '88.21.114.202', NULL, NULL, NULL, NULL, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(8, 2, 243.42, 99.35, NULL, '66.255.81.161', NULL, NULL, NULL, NULL, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(9, 3, 629.25, 99.35, NULL, '36.73.145.147', NULL, NULL, NULL, NULL, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(10, 4, 162.40, 99.35, NULL, '79.42.56.25', NULL, NULL, NULL, NULL, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(13, 1, 101.44, NULL, NULL, '127.0.0.1', NULL, 'alipay', '171916201411', NULL, 11, '2024-06-23 16:40:18', '2024-06-23 17:00:02'),
(14, 1, 101.44, NULL, NULL, '127.0.0.1', NULL, 'alipay', '171916320111', NULL, 12, '2024-06-23 17:00:02', '2024-06-23 17:19:59'),
(15, 3, 132.73, NULL, NULL, '127.0.0.1', NULL, 'testpay', '171916518411', '2024-06-23 23:23:04', 13, '2024-06-23 17:22:22', '2024-06-23 17:52:44'),
(16, 3, 130.87, NULL, NULL, '127.0.0.1', NULL, 'testpay', '171916525811', '2024-06-23 23:24:19', 14, '2024-06-23 17:52:44', '2024-06-23 17:52:44'),
(18, 1, 130.87, NULL, NULL, '127.0.0.1', NULL, 'testpay', '171973878515', NULL, 15, '2024-06-30 09:12:23', '2024-06-30 09:12:23');

-- --------------------------------------------------------

--
-- Table structure for table `plugin_registry`
--

CREATE TABLE `plugin_registry` (
  `name` varchar(100) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute`
--

CREATE TABLE `product_attribute` (
  `title` varchar(255) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_attribute`
--

INSERT INTO `product_attribute` (`title`, `id`, `created_at`, `updated_at`) VALUES
('Color', 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Collar', 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Brand', 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Coffee Genre', 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Flavor', 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Author', 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Publisher', 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Language', 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value`
--

CREATE TABLE `product_attribute_value` (
  `title` varchar(255) NOT NULL,
  `attribute_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_attribute_value`
--

INSERT INTO `product_attribute_value` (`title`, `attribute_id`, `id`, `created_at`, `updated_at`) VALUES
('Blue', 1, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('White', 1, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Round', 2, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('V-Neck', 2, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Polo', 2, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Saleor', 3, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Arabica', 4, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Robusta', 4, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Sour', 5, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Sweet', 5, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('John Doe', 6, 11, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Milionare Pirate', 6, 12, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Mirumee Press', 7, 13, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Saleor Publishing', 7, 14, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('English', 8, 15, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Pirate', 8, 16, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `title` varchar(255) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `background_img` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`title`, `parent_id`, `background_img`, `id`, `created_at`, `updated_at`) VALUES
('Apparel', 0, 'placeholders/products-list/apparel.jpg', 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Accessories', 0, 'placeholders/products-list/accessories.jpg', 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Groceries', 0, 'placeholders/products-list/groceries.jpg', 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Coffees', 3, 'placeholders/products-list/coffees.jpg', 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Candies', 3, 'placeholders/products-list/candies.jpg', 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Books', 0, 'placeholders/products-list/books.jpg', 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_collection`
--

CREATE TABLE `product_collection` (
  `title` varchar(255) NOT NULL,
  `background_img` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_collection`
--

INSERT INTO `product_collection` (`title`, `background_img`, `id`, `created_at`, `updated_at`) VALUES
('Summer collection', 'placeholders/products-list/summer.jpg', 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Winter sale', 'placeholders/products-list/sale.jpg', 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_collection_product`
--

CREATE TABLE `product_collection_product` (
  `product_id` int(11) DEFAULT NULL,
  `collection_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_collection_product`
--

INSERT INTO `product_collection_product` (`product_id`, `collection_id`, `id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 1, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(3, 1, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 1, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(1, 2, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 2, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(3, 2, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 2, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_image`
--

CREATE TABLE `product_image` (
  `image` varchar(255) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_image`
--

INSERT INTO `product_image` (`image`, `product_id`, `id`, `created_at`, `updated_at`) VALUES
('placeholders/t-shirts/3.jpg', 1, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/2.jpg', 2, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/5.jpg', 3, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/2.jpg', 3, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/2.jpg', 4, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/2.jpg', 5, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/6.jpg', 6, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/5.jpg', 7, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/4.jpg', 7, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/6.jpg', 8, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/4.jpg', 8, 11, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/5.jpg', 9, 12, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/3.jpg', 9, 13, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/6.jpg', 10, 14, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/t-shirts/4.jpg', 10, 15, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/7.jpg', 11, 16, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/box-01.jpg', 12, 17, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/box-01.jpg', 13, 18, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/7.jpg', 13, 19, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/4.jpg', 13, 20, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/box-01.jpg', 14, 21, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/4.jpg', 14, 22, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/7.jpg', 15, 23, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/3.jpg', 15, 24, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/4.jpg', 15, 25, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/box-01.jpg', 16, 26, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/7.jpg', 16, 27, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/7.jpg', 17, 28, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/box-01.jpg', 17, 29, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/4.jpg', 18, 30, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/7.jpg', 18, 31, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/7.jpg', 19, 32, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/3.jpg', 19, 33, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/box-01.jpg', 19, 34, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/3.jpg', 20, 35, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/mugs/7.jpg', 20, 36, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-01.jpg', 21, 37, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-02.jpg', 21, 38, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-03.jpg', 22, 39, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-01.jpg', 22, 40, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-02.jpg', 23, 41, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/8.jpg', 23, 42, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-01.jpg', 24, 43, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-01.jpg', 25, 44, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-04.jpg', 26, 45, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/8.jpg', 26, 46, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-01.jpg', 27, 47, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-02.jpg', 28, 48, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-03.jpg', 28, 49, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/8.jpg', 29, 50, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-01.jpg', 29, 51, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-02.jpg', 29, 52, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-02.jpg', 30, 53, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/coffee/coffee-04.jpg', 30, 54, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/1.jpg', 31, 55, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/1.jpg', 32, 56, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/2.jpg', 32, 57, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/2.jpg', 33, 58, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/1.jpg', 33, 59, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/1.jpg', 34, 60, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/2.jpg', 34, 61, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/1.jpg', 35, 62, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/2.jpg', 36, 63, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/1.jpg', 36, 64, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/1.jpg', 37, 65, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/1.jpg', 38, 66, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/1.jpg', 39, 67, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/2.jpg', 39, 68, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/candy/2.jpg', 40, 69, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-05.jpg', 41, 70, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 41, 71, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-05.jpg', 42, 72, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-03.jpg', 42, 73, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-01.jpg', 42, 74, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-05.jpg', 43, 75, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 43, 76, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-03.jpg', 43, 77, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-01.jpg', 43, 78, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-05.jpg', 44, 79, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-04.jpg', 45, 80, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-04.jpg', 46, 81, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-03.jpg', 46, 82, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-05.jpg', 46, 83, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-03.jpg', 47, 84, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-01.jpg', 48, 85, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-05.jpg', 49, 86, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 49, 87, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-04.jpg', 49, 88, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-05.jpg', 50, 89, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-01.jpg', 50, 90, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 50, 91, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-05.jpg', 51, 92, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 51, 93, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 52, 94, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-03.jpg', 52, 95, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 53, 96, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-04.jpg', 54, 97, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 54, 98, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-01.jpg', 55, 99, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 55, 100, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 56, 101, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-01.jpg', 56, 102, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-03.jpg', 56, 103, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-04.jpg', 56, 104, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-05.jpg', 57, 105, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-04.jpg', 57, 106, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-02.jpg', 58, 107, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-01.jpg', 58, 108, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-03.jpg', 58, 109, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-05.jpg', 59, 110, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('placeholders/books/book-01.jpg', 60, 111, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_product`
--

CREATE TABLE `product_product` (
  `title` varchar(255) NOT NULL,
  `on_sale` tinyint(1) DEFAULT NULL,
  `rating` decimal(8,2) DEFAULT NULL,
  `sold_count` int(11) DEFAULT NULL,
  `review_count` int(11) DEFAULT NULL,
  `basic_price` decimal(10,2) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT NULL,
  `product_type_id` int(11) DEFAULT NULL,
  `attributes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attributes`)),
  `description` text DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_product`
--

INSERT INTO `product_product` (`title`, `on_sale`, `rating`, `sold_count`, `review_count`, `basic_price`, `category_id`, `is_featured`, `product_type_id`, `attributes`, `description`, `id`, `created_at`, `updated_at`) VALUES
('Mcknight, Ellis and Allen', 1, 5.00, 0, 0, 45.50, 1, 0, 1, '{\"1\": \"1\", \"2\": \"5\", \"3\": \"6\"}', 'Late election have themselves. Floor since take. Spring week tree interesting.\n\nPopular whatever forget reach. Drive provide spend must much subject yeah with. Special result determine bag edge.\n\nAttention those scene rest. North sound hear pull.\n\nTeach set prevent community away not. Factor president drive three.\n\nDiscussion decision myself tend deal our situation. Civil civil never actually turn use future suddenly. Ok establish soldier address.', 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Benitez Ltd', 1, 5.00, 0, 0, 47.69, 1, 0, 1, '{\"1\": \"2\", \"2\": \"3\", \"3\": \"6\"}', 'Any see their form go side building. Every work should paper Democrat race.\n\nYou traditional here near laugh push leg. Near put miss newspaper turn option. History hand society anything out accept recognize.\n\nService relate learn short article. Keep white physical difference technology minute look force. Hair parent federal deep.\n\nOffer town picture approach ready religious even. Set born per everything pattern approach seek.\n\nDefense same kind speech eight share public. Late her save reality bring particularly likely.', 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Johns PLC', 1, 5.00, 0, 0, 29.44, 1, 1, 1, '{\"1\": \"1\", \"2\": \"5\", \"3\": \"6\"}', 'Much without throughout pass. Door movie watch issue. Agree federal study.\n\nName its seven send day answer respond. Lay writer simple kitchen later attack conference. Note goal movement author owner.\n\nParticular scientist always. Thought film offer. Plan finish where. Plant their this near someone off one.\n\nShoulder town certain hope. Pick customer back no stand hope. Hard front health.\n\nCitizen bed whole.', 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Thompson Inc', 1, 5.00, 0, 0, 24.66, 1, 0, 1, '{\"1\": \"2\", \"2\": \"4\", \"3\": \"6\"}', 'Scene discover sign soon charge lay seem game.\n\nBoy rest million perhaps. Company culture share box claim.\n\nLarge scene level admit rest job. Someone yeah discuss medical late government. Try outside how day.\n\nA than trouble truth eight toward get read. Appear learn marriage.\n\nSimple rather west term. Tax have but development. Affect mother gas perform east drive.', 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Miller Group', 1, 5.00, 0, 0, 63.04, 1, 1, 1, '{\"1\": \"1\", \"2\": \"5\", \"3\": \"6\"}', 'Floor daughter sell already. Article next tree yet low artist item.\n\nPlay good our item even reflect member. Air past through that herself. Tax result everyone be your.\n\nBook must try Republican that. Sport door notice defense century rate current. Rest where thank letter. Defense call realize act nice.\n\nSouth important arrive stuff. Question money relate child. Skill draw yourself hope candidate.\n\nStudy charge hand environment. Beyond more per century sell establish. Them deep step wall throughout discussion.', 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Ramirez, Campbell and Pace', 1, 5.00, 0, 0, 16.41, 1, 1, 1, '{\"1\": \"2\", \"2\": \"3\", \"3\": \"6\"}', 'Might each score wind term lot management. Art soon successful especially wait yourself find fly.\n\nActivity should fly instead structure. Herself challenge service sure. Participant when similar cell research hundred.\n\nHowever son seem scene prove hospital sometimes. Five what American tree although at traditional couple. Prepare high our operation cell young.\n\nOnto develop star cell avoid. Technology for do painting wrong behind single.\n\nRegion fish agreement up effort read high. Source nor career until.', 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Gomez, Moody and Mason', 1, 5.00, 0, 0, 29.56, 1, 0, 1, '{\"1\": \"2\", \"2\": \"5\", \"3\": \"6\"}', 'Soldier leader ability old rate. Government Congress bad resource. Truth avoid first section audience protect.\n\nProbably road information inside close send. Every kid since course event although data.\n\nTheory also it stand east. Life bar decade least save.\n\nBefore hit treatment family decide blood force.\n\nSmile tell all thus such. Remain condition enjoy. Base left gas return remember. Tough either fall turn.', 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Meyer, Rodriguez and Holmes', 1, 5.00, 0, 0, 8.23, 1, 1, 1, '{\"1\": \"2\", \"2\": \"3\", \"3\": \"6\"}', 'Set recognize peace social change record catch. Service top approach community share. Bit happen summer.\n\nSuch father floor here them thing law. Room Democrat serve wall.\n\nDecade even now again social red education thus. Source religious different three important. Wait traditional thought operation term.\n\nSingle quality structure thus herself animal gun. Around run firm message share cultural trade.\n\nRequire compare suddenly door. Body check tonight listen. Adult enjoy serious treat cover ahead doctor safe.', 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Williams-Nash', 1, 5.00, 0, 0, 3.49, 1, 1, 1, '{\"1\": \"2\", \"2\": \"3\", \"3\": \"6\"}', 'Best whatever range concern health. Health growth defense draw history president. Buy single past sign mouth by.\n\nHope begin pick north left film cause. Look no sound particularly control magazine nation.\n\nWithout now maybe deep stay Congress deep. Order that staff artist. Apply skin agency discover newspaper.\n\nMaybe instead choose soon light prove. According half chair. Recent field save plan.\n\nNext would concern. Moment attention thus art call.', 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Perry LLC', 1, 5.00, 0, 0, 51.44, 1, 0, 1, '{\"1\": \"1\", \"2\": \"5\", \"3\": \"6\"}', 'Hundred I trouble bit. Write though leader foreign way white.\n\nArticle candidate back manage huge personal company. Safe yourself cost sport attack base last. Quite health site fish.\n\nReveal become meeting short throw late thousand. Of especially second only. Describe require business might response huge pattern.\n\nNorth window them coach position cover avoid. I positive middle less city fast week instead.\n\nServe later camera me describe husband.', 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Reynolds, Jensen and Barnett', 1, 5.00, 0, 0, 91.93, 2, 0, 2, '{\"3\": \"6\"}', 'Available less require sense firm field food friend. Among carry husband understand to president. Too debate family nor popular popular.\n\nThere impact to technology stuff bag ability. Individual marriage say organization strategy.\n\nMajority others thus help help management. Market middle bag score improve wish. Day watch week message if remember.\n\nAddress Republican no method. White feeling candidate. Final data occur back public.\n\nWhen open bad practice. Anyone smile eye rock question accept lawyer about.', 11, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Mcdonald Group', 1, 5.00, 0, 0, 1.53, 2, 0, 2, '{\"3\": \"6\"}', 'Fear third story down election term. Responsibility action matter know. Where man option marriage leave laugh war.\n\nTrip method effort because. Town community when with. Owner during indicate data face product speech.\n\nArticle bed save difference exist various attorney. Understand bad from argue set mouth.\n\nHerself ground summer character to board act. Begin where tree. They Mrs difference.\n\nDrop another that purpose experience young television. Pretty entire coach memory. Decide relate page.', 12, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Holland and Sons', 1, 5.00, 0, 0, 15.31, 2, 0, 2, '{\"3\": \"6\"}', 'Him expert his deep some tonight rest. Information action image each democratic court. Edge reach court run.\n\nStructure collection modern article off hot. No but hair.\n\nHim budget let third perhaps window practice. Front prepare capital. Pattern consumer near appear.\n\nPm learn although hand expert move happen.\n\nPerformance figure hot find. List doctor term goal over want keep. Soldier reveal wait likely brother pick.', 13, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Richardson PLC', 1, 5.00, 0, 0, 30.57, 2, 0, 2, '{\"3\": \"6\"}', 'Agree camera Mr book travel stage. Center politics learn company perhaps country. Bit fall machine.\n\nAmong child when conference. Artist billion if should. Whose trade effort event must. Light water law near travel.\n\nSecond old there. Both owner wait space stop watch. Four radio perhaps we about from score.\n\nRepublican traditional party against amount. Among according yes no.\n\nCapital theory talk buy question discuss side human. Believe manager set picture cost.', 14, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Elliott Inc', 1, 5.00, 0, 0, 2.67, 2, 1, 2, '{\"3\": \"6\"}', 'So beautiful cut beyond quality. Wait medical issue hand food really seven. Economic second table decision of.\n\nAmong court heart matter. Unit hospital upon discuss size manage. Middle laugh care hundred approach point art.\n\nDescribe author home media politics base speak. Marriage among popular learn table station push. Size may decision set piece whether song. Local protect cultural your public.\n\nDifficult left professional option more. Shake reveal that dream when heart nor range. Professional several who just can wait.\n\nReality Mr dark mission long another cover. Out to wide president. Argue environmental account world share.', 15, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Harrison, Kelley and Carlson', 1, 5.00, 0, 0, 71.15, 2, 1, 2, '{\"3\": \"6\"}', 'Off author rate listen save sense drop. Hair some blue.\n\nRace officer different experience general. Use will identify. Between network out few common.\n\nSystem over glass site director. Avoid them along see hour or use. Daughter check form responsibility.\n\nThemselves strategy total nice floor box. Activity floor successful approach. Month treatment adult campaign tend fund situation.\n\nCentury find mouth evidence. Science may decision green part add drop purpose.', 16, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Cervantes-Bryant', 1, 5.00, 0, 0, 22.82, 2, 0, 2, '{\"3\": \"6\"}', 'At detail individual bag coach hair least reach. Store cell later.\n\nOthers remain dream art bag assume. Market boy discover particularly thought position left meet.\n\nProperty between much. Mouth nice a foot form kid data. Action rather moment now eye.\n\nCertain theory particular garden finish choose perform. Some expect parent sell plan suffer since. Remain cover side.\n\nNews popular one size. Face decision moment material plan message head.', 17, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Ballard, Frye and Barber', 1, 5.00, 0, 0, 8.32, 2, 0, 2, '{\"3\": \"6\"}', 'There bag business war. Require teach these.\n\nChance to fund. Population receive middle development tree.\n\nRadio tough about own.\n\nOrder again author school along. Believe big reveal anything. Picture leader about run tend.\n\nClear training answer final whose matter effect. Middle perform garden shoulder really we writer. Financial seem onto plan edge.', 18, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Landry-Robbins', 1, 5.00, 0, 0, 12.91, 2, 1, 2, '{\"3\": \"6\"}', 'Source benefit instead. Writer compare full until ground international. Force media great write recent wonder.\n\nTable worry these listen.\n\nStay ever trip high house store color choose. Read writer bad three song. War style guess there. Imagine usually different physical.\n\nProject up home author material size. Military road describe ability their leg.\n\nRepublican issue last summer be ready crime. Discuss inside its step seat hospital oil.', 19, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Jones, Roberson and Robertson', 1, 5.00, 0, 0, 46.44, 2, 1, 2, '{\"3\": \"6\"}', 'Entire white me. Term station dark. Base work any every good generation.\n\nTrouble discuss professional likely majority. Learn clearly modern or show economy. Message reduce option little truth.\n\nGame scientist democratic job detail. Wonder tree activity fast real here. Different available only everything material relationship try.\n\nStage animal design prove community material. Money concern race shoulder. Mission point word unit be body challenge in.\n\nThemselves item chance medical follow break change. Tonight team fund develop scene space. Central short type respond.', 20, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Harris, Powell and Martinez', 1, 5.00, 0, 0, 43.77, 4, 1, 3, '{\"3\": \"6\", \"4\": \"8\"}', 'Box capital need want lay tend. Guess certain heart.\n\nCourse age once prove. Occur discover argue option view edge parent.\n\nDoor teach against free series color cold. Power defense significant somebody chance step. Move peace since party.\n\nHundred candidate popular wonder. Would serious later individual idea activity it. A author send.\n\nProbably share shoulder pressure record. Week each huge Congress determine fish. Thought other glass guess.', 21, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Andersen and Sons', 1, 5.00, 0, 0, 67.19, 4, 0, 3, '{\"3\": \"6\", \"4\": \"8\"}', 'Never community realize receive. Under reflect situation anything southern build. Enough practice thank hot gas.\n\nTwo kitchen today that. Wife read big loss game north. Short entire production series son always. Indeed five performance third.\n\nDesign exist ball speech. View again item operation cold.\n\nStop loss claim official case. Factor team ground sea agreement play. Southern whatever project day moment else.\n\nLoss side edge data through establish.', 22, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Smith LLC', 1, 5.00, 0, 0, 9.85, 4, 1, 3, '{\"3\": \"6\", \"4\": \"7\"}', 'Attorney include reduce young although single price. Cell near million serious. List must face society consider.\n\nTeach tend employee tell rule. Phone she bit piece. Sit decade later occur education sense likely.\n\nThus well focus coach necessary. Attorney race cell tough develop never break entire. Two peace trade well.\n\nOn face individual thought. House world hotel protect job window real.\n\nStar whatever news buy figure last respond defense. Would Republican role right above if. Time financial develop put her let.', 23, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Scott-Cunningham', 1, 5.00, 0, 0, 39.87, 4, 1, 3, '{\"3\": \"6\", \"4\": \"8\"}', 'Indicate report reduce with. Off seem sell others help.\n\nAccount police family magazine social six. Direction television ready experience able notice. Beat federal close.\n\nParent bag someone research find mother move not. Provide accept style huge. Agency away book important.\n\nWrite we organization. Let during make five worker shoulder though before. Late finally news summer later message sure.\n\nBlack growth share capital along amount cold page. Pressure candidate food time range real threat. Nor charge for then should relate.', 24, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Lambert-Turner', 1, 5.00, 0, 0, 18.54, 4, 0, 3, '{\"3\": \"6\", \"4\": \"8\"}', 'Church year face she each. Respond institution federal politics hit environment. Key receive nature whether particularly war left.\n\nWord where car blue billion nation her. Leader speak once face. Need artist event word form four.\n\nInternational begin result. Arrive customer movie science. They million card recent school and draw. Clear act quality perhaps former structure likely occur.\n\nTop one history low situation Mr. It beautiful often consumer.\n\nRun strong technology win. Free call generation approach seven rest next on. College moment receive policy.', 25, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Fisher, Lane and Dawson', 1, 5.00, 0, 0, 18.66, 4, 0, 3, '{\"3\": \"6\", \"4\": \"7\"}', 'Future policy only start. Reveal pass wait.\n\nFamily full business my name behavior sure foreign. Reality anything bring political nature. School store spend field leave.\n\nAvoid mission and letter arm partner offer billion. Dinner choice successful bag professional choose product. Night several particularly third history everything.\n\nChance discuss executive effect walk wish ever account. Rule claim story popular yourself themselves him. City sell professional ever test all thus.\n\nActually until several million nearly similar step we. Town space could throughout onto somebody concern.', 26, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Burns, Lee and Kennedy', 1, 5.00, 0, 0, 78.34, 4, 0, 3, '{\"3\": \"6\", \"4\": \"8\"}', 'Nature list situation popular. Voice although ask. Again thank mouth moment recent law.\n\nAnother activity for occur tonight participant manager create. Baby minute hot trip tend family. Person chair must method into get.\n\nHim international across total partner increase against. True treat program defense sea study. Town chair if deal money.\n\nRange region go when. Exactly sea significant clear some still military for. Describe seat change.\n\nState media contain family last professional week wrong. Matter course Democrat role benefit fund. Be treatment hair war early.', 27, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Patterson Ltd', 1, 5.00, 0, 0, 14.25, 4, 1, 3, '{\"3\": \"6\", \"4\": \"8\"}', 'Note situation which foot environmental site through. Enough watch debate though adult wrong. Response bring event TV none behavior because.\n\nAlready for into yard baby involve people. Significant book everything just stand which make.\n\nKeep fund fear local suggest. Hear friend over parent present worker note present.\n\nKnowledge coach different argue able case majority charge. Explain blue goal team hospital.\n\nOccur long environment any these figure sport teach. Director likely relationship us compare thousand.', 28, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Ayala Inc', 1, 5.00, 0, 0, 14.18, 4, 0, 3, '{\"3\": \"6\", \"4\": \"7\"}', 'Us soldier nation recent rate meeting clear. Control sometimes reflect use. Hundred point unit these wife.\n\nEveryone food determine involve. Opportunity necessary officer heart for page ask.\n\nStock about similar paper paper. Month traditional health study book. So find late Mr girl behavior.\n\nHouse join involve knowledge. Performance memory truth less adult.\n\nLater difficult garden thousand buy fill. Report training cold. Low red time coach keep.', 29, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Myers Group', 1, 5.00, 0, 0, 50.41, 4, 0, 3, '{\"3\": \"6\", \"4\": \"7\"}', 'Analysis song again prevent wide practice.\n\nFather once tonight think nature. Court else add truth seem walk use whether. Campaign put popular evidence. So easy black stage production center.\n\nCultural week side car paper situation law. Build three range which. Audience address environment test.\n\nMagazine have put rise region. Decade could wall store herself century. Pretty strategy here family after she style after.\n\nCenter treatment blue professional want may. Level such suggest address interest.', 30, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Welch and Sons', 1, 5.00, 0, 0, 47.81, 5, 1, 4, '{\"3\": \"6\", \"5\": \"10\"}', 'Close election list responsibility television PM. Chair weight traditional low.\n\nIdea easy expect anything however oil. Safe lot detail couple citizen.\n\nUnder between south himself. Certain break lay floor occur likely. Financial other another and much deep. Music wife face.\n\nBoy car executive administration college term standard rather. Figure push happen weight. Type garden commercial firm sister.\n\nEveryone page blue. Single team example between off.', 31, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Castillo Group', 1, 5.00, 0, 0, 79.83, 5, 0, 4, '{\"3\": \"6\", \"5\": \"10\"}', 'Trip right term among fire Democrat. Artist point move turn than. Year hotel arrive bank trip.\n\nToday care blue church usually skin. For executive room audience arm door view interesting.\n\nAnimal during similar fact. Send pull mission author majority mention. Recognize threat treat southern fill main official mind.\n\nWhich however front apply total ever. With record company none. Full subject speech perform since. Employee hair simply without.\n\nFast likely avoid blood. Goal painting over those apply community shake.', 32, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Russell-Ramirez', 1, 5.00, 0, 0, 27.92, 5, 0, 4, '{\"3\": \"6\", \"5\": \"10\"}', 'Pay agreement evidence size town leave so. Before different yard serve. Thought station election although form never together.\n\nChoose dinner I strong method beautiful. On somebody difficult system movie fast physical. Also later already could then. Push finish with present side happy.\n\nMost oil start government cause gun position. Whole another bag front may capital.\n\nHim point institution film through. Wrong hope true own away significant.\n\nDream economy new better think improve. Wait whom agreement enter each will. Technology attorney meet usually with Democrat.', 33, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Porter-Nicholson', 1, 5.00, 0, 0, 26.87, 5, 1, 4, '{\"3\": \"6\", \"5\": \"10\"}', 'Necessary body though itself also pick. Reduce avoid particularly foreign key fight scientist. Police get occur factor set.\n\nLeader likely somebody standard choice list several. Base most successful friend develop money.\n\nShare sea among sometimes. Sell price attention new much really attack. Answer glass himself box animal.\n\nForeign those industry how. Though great identify black political may. Upon grow believe rule.\n\nWhole foreign song. State free size cup rise. Fill hear paper win.', 34, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Shepherd-Contreras', 1, 5.00, 0, 0, 91.88, 5, 0, 4, '{\"3\": \"6\", \"5\": \"10\"}', 'Particular control follow management right. Each carry experience today them. Trial say else.\n\nReality city study. Hear detail industry no debate today high. Network read institution wind.\n\nSeason increase effect store up. Language answer law audience after. Ready president suffer anyone until practice media. Off toward especially commercial.\n\nAge arrive close sort opportunity him agency. Modern contain civil list resource.\n\nStory forward exist class form rather bag practice. Sense wait doctor she however. Until American control blood book production.', 35, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Stark PLC', 1, 5.00, 0, 0, 5.81, 5, 0, 4, '{\"3\": \"6\", \"5\": \"9\"}', 'Stock fact investment life themselves more pay. End rise hold old.\n\nAct finish you. Responsibility sign reflect.\n\nThat mention institution can society ready its. Baby firm value describe body. On manage fall voice growth.\n\nRather cultural machine sit chair. Clear first two hand present.\n\nHelp wall according upon. Kid past between.', 36, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Sampson, Ruiz and Cross', 1, 5.00, 0, 0, 95.25, 5, 1, 4, '{\"3\": \"6\", \"5\": \"9\"}', 'Policy there myself fast evening should. Fish pattern military weight.\n\nAmount language remain type. Old not which young cover. Purpose detail term serious name.\n\nFly return protect treat wall. Skill need get begin.\n\nAdd act national.\n\nShoulder voice step identify economy moment quite. Carry gas involve safe dark part quality enjoy. Common there air television.', 37, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Tran LLC', 1, 5.00, 0, 0, 52.85, 5, 0, 4, '{\"3\": \"6\", \"5\": \"9\"}', 'Sit much TV hospital could some. Brother visit kid great her machine head. Their town cover information page smile. Data get attention second foot forward because.\n\nSuddenly production worry high turn individual movement. Foreign where blood be.\n\nRange unit fund language weight magazine might. Into from audience where rule wear common.\n\nVoice though population hit whether admit. Call lead peace cover likely special even. Capital light none lead.\n\nDifference audience necessary result offer song after. Talk center fight relationship real prevent son. Should plant medical boy.', 38, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Crawford LLC', 1, 5.00, 0, 0, 41.64, 5, 0, 4, '{\"3\": \"6\", \"5\": \"10\"}', 'Administration such real race whatever station. Enough wear yet character general yet point. Some sign cup member bed.\n\nContain especially on security part people identify store. Approach environment boy happy democratic important professional. Tv play write sport treatment class indeed.\n\nAgo support own win successful argue if. Political executive certain action. Computer serve game two should. Well quality popular together woman.\n\nCourse item might. Better do grow for relationship hot. Middle Mrs himself eight week.\n\nBillion rise north road. Control size tax entire majority most dinner.', 39, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Baker and Sons', 1, 5.00, 0, 0, 70.34, 5, 0, 4, '{\"3\": \"6\", \"5\": \"9\"}', 'End when employee realize decide performance official. One finish behavior fast ago science.\n\nRed street wonder way. There there soldier ask much talk outside entire. Space behind major to agency staff.\n\nBoy never together thank. Across everyone social eye pull.\n\nSocial us return expect against politics walk. Particular dog player shake century investment play always.\n\nEight director tough throw perform forget southern bring. Third affect since place threat machine road history. Mission focus indicate property type which.', 40, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Rios PLC', 1, 5.00, 0, 0, 74.44, 6, 1, 5, '{\"6\": \"12\", \"7\": \"14\", \"8\": \"15\"}', 'Someone suddenly none into. Mouth structure effort provide window pressure.\n\nFather man establish. Wind old her reality ever concern.\n\nBe clearly enjoy move face. Then recently any party. Including part now improve success market door floor.\n\nComputer painting large sister gun know. Minute break her gas reality center.\n\nEveryone threat along development dog. Age attorney really college mean behavior ago.', 41, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Johns-Good', 1, 5.00, 0, 0, 26.11, 6, 1, 5, '{\"6\": \"12\", \"7\": \"13\", \"8\": \"15\"}', 'Need look five sound whom also remain. Stop pay thousand senior left star western.\n\nIdea gun nearly notice respond big similar. Lawyer scene stock culture training if reach. Degree better American air per.\n\nTrue peace seek fund bill. House rule around other door water off six. Hot style data both campaign visit.\n\nAway somebody financial character high despite.\n\nDog join attack series executive. Single such contain rich especially tree discover apply.', 42, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Hernandez, Anderson and Wallace', 1, 5.00, 0, 0, 54.74, 6, 0, 5, '{\"6\": \"11\", \"7\": \"13\", \"8\": \"16\"}', 'Goal child like seek. Thus age trouble inside leg house fall. Dark even road tree life deal.\n\nSource then time actually up. Scientist whether best. Knowledge design nice.\n\nGas dinner matter including worry. Laugh method end though author.\n\nGeneral experience history rest any. Include visit year president candidate design first politics.\n\nAcross action my letter attention. Fill movement fine. Hospital series role page.', 43, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Nelson Ltd', 1, 5.00, 0, 0, 20.50, 6, 0, 5, '{\"6\": \"12\", \"7\": \"14\", \"8\": \"16\"}', 'Month wait consumer place accept moment change. Rate nothing stage radio house everything lead. Consider pattern company outside guess ability very research.\n\nProduct mind leg however son. Sell figure modern news. Perform happen hit style capital meet important.\n\nHot south listen deal if economy. Simply process trial true community maybe debate. Write then bank past movie risk.\n\nApply character outside store foot debate building direction. Because family difficult according standard become person. Six page this month laugh teacher. Street rule ahead develop need during town.\n\nModern increase between long see. Tree ready prevent receive goal well so. Enough describe quickly.', 44, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Wise, Morales and Cameron', 1, 5.00, 0, 0, 34.23, 6, 0, 5, '{\"6\": \"11\", \"7\": \"14\", \"8\": \"16\"}', 'Sometimes ball carry generation indeed what. Compare end those cover before. Simply his it heavy whom line.\n\nChange for green eight develop partner guess. Red service paper news skill write meeting best.\n\nColor trouble city season. Herself poor recently room learn street.\n\nYourself bag fish against free rise. Already election thing answer practice wish agent college. Stock thing economic discuss across collection.\n\nScience wonder quite radio clearly. Only be man ground part.', 45, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Sawyer-Sullivan', 1, 5.00, 0, 0, 60.06, 6, 1, 5, '{\"6\": \"12\", \"7\": \"13\", \"8\": \"15\"}', 'Beat audience wind environment value simply. Consider bring fast great. Administration whose realize exactly image fall theory.\n\nEvidence war impact fear. Decide south manage suffer that space.\n\nDifference probably brother time. Sell both attention under.\n\nOperation positive machine yard idea black executive. Drug subject or crime American keep. Help around identify nice.\n\nStreet let spend property father cold mission. Else bank house commercial minute.', 46, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Curry-Sampson', 1, 5.00, 0, 0, 34.09, 6, 1, 5, '{\"6\": \"11\", \"7\": \"14\", \"8\": \"16\"}', 'Pretty middle alone wife. Somebody board partner other month floor.\n\nExecutive risk friend wait. Young set attention oil big smile. Industry wait produce interest very purpose economic.\n\nOnly woman experience resource eat. Ok represent audience.\n\nRecognize feel theory move quality. Coach have family practice mention.\n\nEstablish send TV others. Car wait up remember wrong else. Over project them. Fast professional hospital myself.', 47, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Smith Inc', 1, 5.00, 0, 0, 92.59, 6, 1, 5, '{\"6\": \"11\", \"7\": \"14\", \"8\": \"15\"}', 'Miss leg loss dinner difference. More read also act people.\n\nDetermine radio north message show beat treat.\n\nThere son fill never ten. Meet course seat drop at goal face trouble. In then never represent work nothing contain.\n\nAnalysis way response professor three month mind nation. Reduce because responsibility plan movie.\n\nBase level call. Our change safe treatment west.', 48, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Novak, Woodward and Phelps', 1, 5.00, 0, 0, 46.04, 6, 0, 5, '{\"6\": \"11\", \"7\": \"14\", \"8\": \"16\"}', 'Eight result rule get realize once fund. Mean traditional likely stay try safe. Lot agreement available shoulder example consider.\n\nRise page nation will resource another president.\n\nDesign because discussion lose whose walk. Keep culture rest a their watch.\n\nLife try man each wall early. Also human now chance which want near.\n\nStay lawyer spend institution talk ever dinner. Upon campaign stage.', 49, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Foster Inc', 1, 5.00, 0, 0, 74.29, 6, 0, 5, '{\"6\": \"11\", \"7\": \"14\", \"8\": \"16\"}', 'Radio animal radio recognize fly never.\n\nPush perhaps offer hit one together deep. Wish thousand charge science court Mr improve politics. Sometimes race page throw big authority.\n\nType tend little perform administration according treatment. Itself power consider work crime.\n\nAttention hold loss international trial. Bill this without water senior.\n\nOperation everything paper last true choice. Night ten else street leg.', 50, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Ayers, Horton and Boyd', 1, 5.00, 0, 0, 12.40, 6, 0, 6, '{\"6\": \"12\", \"7\": \"14\", \"8\": \"16\"}', 'Story control others bad forget. Environmental center audience result like against night. Church according benefit arrive team join behavior.\n\nThem certain opportunity beat together finally. Able wrong end husband government. Once card later dog statement civil sister.\n\nMay week little natural already bad name deep. Head month while least few state. Service dream would exactly training bag.\n\nSomeone husband blue own. Want either describe particular reduce.\n\nCall culture brother worry information act cost.', 51, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Gibson Group', 1, 5.00, 0, 0, 53.96, 6, 0, 6, '{\"6\": \"12\", \"7\": \"14\", \"8\": \"16\"}', 'More education color discussion quite scientist very. Whatever trial environment film color unit. Activity listen support reduce candidate.\n\nBehavior body impact notice bring represent various. Produce collection nothing visit dog medical kind.\n\nLeast try respond call trade.\n\nChallenge best small difficult difference. Write see career strong reflect today arm. Ahead cost young term scene base state medical.\n\nIn different same himself seek economy week. I attention system position pattern establish detail. Give well example forget.', 52, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Sanchez-Lewis', 1, 5.00, 0, 0, 22.44, 6, 0, 6, '{\"6\": \"12\", \"7\": \"14\", \"8\": \"16\"}', 'Arrive everyone bar factor against. Million fire author particularly.\n\nSeven the beautiful fight.\n\nProfessor Mr modern still effect beautiful nor. Peace claim impact run. Level hope begin box beautiful ago.\n\nIdentify company crime market operation school. Question paper read thus. Down discussion commercial you fine.\n\nTry without drop include later work north language. Movie provide space task spend.', 53, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Carter-Jones', 1, 5.00, 0, 0, 52.54, 6, 0, 6, '{\"6\": \"11\", \"7\": \"13\", \"8\": \"15\"}', 'Travel law perform lead admit by citizen. System loss toward century staff water.\n\nSummer whom call according campaign appear involve want. War director as four. Activity capital agree yes social.\n\nImpact condition his national rule. Next section debate billion ok. Keep economy at easy but know note.\n\nAt concern if. Management with hospital you financial. Six also individual radio daughter hold.\n\nSenior artist help dream threat lot.', 54, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Lowery, Collins and Stewart', 1, 5.00, 0, 0, 59.79, 6, 0, 6, '{\"6\": \"12\", \"7\": \"14\", \"8\": \"15\"}', 'Network final knowledge newspaper officer quite figure. Each physical share home affect investment. Thing certainly Mrs sense vote reflect.\n\nThe ask entire forget break. Sport son civil contain you. Weight crime case good former record. Experience floor include with study yourself front.\n\nToo score thank watch you subject difficult arrive. There home set until room glass.\n\nWest partner room nice body. Factor north able policy fast size.\n\nControl ability dinner chair. Suddenly produce increase bad loss service I. Course maybe that outside happy budget more.', 55, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Larsen PLC', 1, 5.00, 0, 0, 19.16, 6, 0, 6, '{\"6\": \"12\", \"7\": \"13\", \"8\": \"16\"}', 'American happen leg goal finally article paper. Church the beyond Mr million nothing. Key already particular. Option risk leave.\n\nSuch that read store. Change month take real issue six billion. Issue lawyer term.\n\nWorker hair religious main. And southern character strategy without conference. Task chair cell more shake message goal. Economy media animal fly reality visit.\n\nDifferent fund discover sport care put hundred. Whole may move usually because pull sometimes or. Mean interest front may information hard.\n\nCertainly save economic senior large market. Red nothing write everything large long care weight. Million seek quality by see.', 56, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Bennett Group', 1, 5.00, 0, 0, 87.02, 6, 1, 6, '{\"6\": \"12\", \"7\": \"13\", \"8\": \"16\"}', 'Voice realize officer arm my. Both still her paper him newspaper interest.\n\nTraining enjoy expect couple truth. Almost measure total despite. Late lose forget describe success ask budget.\n\nPull be budget. Sit still how. Lawyer particular return college often senior. Light light free may great everyone oil imagine.\n\nKnowledge alone continue old but interest. Administration north any during military candidate. She seem son fine.\n\nStudy determine knowledge try wall. Second east push race wide themselves ten. Man every bill discover.', 57, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Bradley-Noble', 1, 5.00, 0, 0, 89.95, 6, 1, 6, '{\"6\": \"11\", \"7\": \"13\", \"8\": \"16\"}', 'Exist condition seven glass. Establish whose finally but property push letter. Stop some difficult thank girl follow speech.\n\nMust account old money. Artist share garden well way fast. Chance we realize decade a yet small.\n\nSame mother ago control. Author seat under general marriage. Can score song positive power write could.\n\nEven yourself use whose floor. Bank term kitchen. Effort manager else address company stock. Find group difficult.\n\nAppear fall bring people article indicate season technology. Prove believe happen southern nation push. Agency wait media piece still tonight.', 58, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Morris, Welch and Obrien', 1, 5.00, 0, 0, 81.79, 6, 0, 6, '{\"6\": \"11\", \"7\": \"14\", \"8\": \"15\"}', 'Look actually next example long price. Pm tax care later skill investment ask. Day once issue.\n\nNo whom people every idea. Hundred beautiful stay western deep knowledge too. Expect degree will knowledge.\n\nModern old size.\n\nGet pay within over important trouble. Do last degree blue author pay child. Whether different citizen scene interview imagine. Amount interest box else.\n\nMemory recently drive chair seat.', 59, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Hanson-Moody', 1, 5.00, 0, 0, 81.75, 6, 1, 6, '{\"6\": \"11\", \"7\": \"14\", \"8\": \"16\"}', 'Receive candidate help. Item pick figure certain true.\n\nArgue suggest next left. Because your lay miss.\n\nHundred strategy agent property. Defense floor discussion quickly husband. Newspaper the stuff special drive man by. Learn discussion these the treat eye.\n\nPrevent reason first actually. Hundred game culture share Democrat year test.\n\nDirector while simple surface your ability cover. She somebody style home truth type.', 60, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_type`
--

CREATE TABLE `product_type` (
  `title` varchar(255) NOT NULL,
  `has_variants` tinyint(1) DEFAULT NULL,
  `is_shipping_required` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_type`
--

INSERT INTO `product_type` (`title`, `has_variants`, `is_shipping_required`, `id`, `created_at`, `updated_at`) VALUES
('T-Shirt', 1, 1, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Mugs', 1, 1, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Coffee', 1, 1, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Candy', 1, 1, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('E-books', 1, 0, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Books', 1, 1, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_type_attribute`
--

CREATE TABLE `product_type_attribute` (
  `product_type_id` int(11) DEFAULT NULL,
  `product_attribute_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_type_attribute`
--

INSERT INTO `product_type_attribute` (`product_type_id`, `product_attribute_id`, `id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(1, 2, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(1, 3, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(2, 3, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(3, 4, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(3, 3, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 5, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(4, 3, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(5, 6, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(5, 7, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(5, 8, 11, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(6, 6, 12, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(6, 7, 13, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
(6, 8, 14, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_variant`
--

CREATE TABLE `product_variant` (
  `sku` varchar(32) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `price_override` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `quantity_allocated` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_variant`
--

INSERT INTO `product_variant` (`sku`, `title`, `price_override`, `quantity`, `quantity_allocated`, `product_id`, `id`, `created_at`, `updated_at`) VALUES
('1-1337', 'XS', 0.00, 39, 0, 1, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('1-1338', 'S', 0.00, 48, 0, 1, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('1-1339', 'M', 0.00, 20, 0, 1, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('1-1340', 'L', 0.00, 19, 0, 1, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('1-1341', 'XL', 0.00, 37, 0, 1, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('1-1342', 'XXL', 0.00, 35, 0, 1, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('2-1337', 'XS', 0.00, 10, 0, 2, 7, '2024-06-23 16:28:21', '2024-06-23 17:52:44'),
('2-1338', 'S', 0.00, 33, 0, 2, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('2-1339', 'M', 0.00, 33, 0, 2, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('2-1340', 'L', 0.00, 4, 0, 2, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('2-1341', 'XL', 0.00, 12, 0, 2, 11, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('2-1342', 'XXL', 0.00, 3, 0, 2, 12, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('3-1337', 'XS', 0.00, 34, 1, 3, 13, '2024-06-23 16:28:21', '2024-06-30 09:16:24'),
('3-1338', 'S', 0.00, 43, 0, 3, 14, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('3-1339', 'M', 0.00, 11, 0, 3, 15, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('3-1340', 'L', 0.00, 46, 0, 3, 16, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('3-1341', 'XL', 0.00, 30, 0, 3, 17, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('3-1342', 'XXL', 0.00, 19, 0, 3, 18, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('4-1337', 'XS', 0.00, 23, 0, 4, 19, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('4-1338', 'S', 0.00, 27, 0, 4, 20, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('4-1339', 'M', 0.00, 24, 0, 4, 21, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('4-1340', 'L', 0.00, 49, 0, 4, 22, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('4-1341', 'XL', 0.00, 22, 0, 4, 23, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('4-1342', 'XXL', 0.00, 36, 0, 4, 24, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('5-1337', 'XS', 0.00, 47, 2, 5, 25, '2024-06-23 16:28:21', '2024-06-30 09:19:05'),
('5-1338', 'S', 0.00, 39, 0, 5, 26, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('5-1339', 'M', 0.00, 27, 0, 5, 27, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('5-1340', 'L', 0.00, 16, 0, 5, 28, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('5-1341', 'XL', 0.00, 50, 0, 5, 29, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('5-1342', 'XXL', 0.00, 37, 0, 5, 30, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('6-1337', 'XS', 0.00, 47, 0, 6, 31, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('6-1338', 'S', 0.00, 8, 0, 6, 32, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('6-1339', 'M', 0.00, 49, 0, 6, 33, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('6-1340', 'L', 0.00, 22, 0, 6, 34, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('6-1341', 'XL', 0.00, 20, 0, 6, 35, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('6-1342', 'XXL', 0.00, 50, 0, 6, 36, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('7-1337', 'XS', 0.00, 46, 0, 7, 37, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('7-1338', 'S', 0.00, 1, 0, 7, 38, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('7-1339', 'M', 0.00, 12, 0, 7, 39, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('7-1340', 'L', 0.00, 27, 0, 7, 40, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('7-1341', 'XL', 0.00, 37, 0, 7, 41, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('7-1342', 'XXL', 0.00, 31, 0, 7, 42, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('8-1337', 'XS', 0.00, 39, 0, 8, 43, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('8-1338', 'S', 0.00, 50, 0, 8, 44, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('8-1339', 'M', 0.00, 7, 0, 8, 45, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('8-1340', 'L', 0.00, 1, 0, 8, 46, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('8-1341', 'XL', 0.00, 39, 0, 8, 47, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('8-1342', 'XXL', 0.00, 44, 0, 8, 48, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('9-1337', 'XS', 0.00, 24, 2, 9, 49, '2024-06-23 16:28:21', '2024-06-23 17:00:02'),
('9-1338', 'S', 0.00, 49, 0, 9, 50, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('9-1339', 'M', 0.00, 35, 0, 9, 51, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('9-1340', 'L', 0.00, 22, 0, 9, 52, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('9-1341', 'XL', 0.00, 42, 0, 9, 53, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('9-1342', 'XXL', 0.00, 46, 0, 9, 54, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('10-1337', 'XS', 0.00, 6, 0, 10, 55, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('10-1338', 'S', 0.00, 22, 0, 10, 56, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('10-1339', 'M', 0.00, 10, 0, 10, 57, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('10-1340', 'L', 0.00, 46, 0, 10, 58, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('10-1341', 'XL', 0.00, 31, 0, 10, 59, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('10-1342', 'XXL', 0.00, 33, 0, 10, 60, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('11-86509', NULL, 0.00, 7, 0, 11, 61, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('12-5166', NULL, 0.00, 39, 0, 12, 62, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('13-83052', NULL, 0.00, 37, 0, 13, 63, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('14-8582', NULL, 0.00, 46, 0, 14, 64, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('15-29905', NULL, 0.00, 16, 2, 15, 65, '2024-06-23 16:28:21', '2024-06-30 09:51:55'),
('16-17715', NULL, 0.00, 7, 0, 16, 66, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('17-60289', NULL, 0.00, 43, 0, 17, 67, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('18-23812', NULL, 0.00, 3, 0, 18, 68, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('19-5417', NULL, 0.00, 7, 0, 19, 69, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('20-16402', NULL, 0.00, 25, 0, 20, 70, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('21-1337', '100g', 140.59, 3, 0, 21, 71, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('21-1338', '250g', 138.98, 10, 0, 21, 72, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('21-1339', '500g', 71.07, 22, 0, 21, 73, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('21-1340', '1kg', 44.89, 48, 0, 21, 74, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('22-1337', '100g', 95.19, 21, 0, 22, 75, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('22-1338', '250g', 86.24, 3, 0, 22, 76, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('22-1339', '500g', 74.51, 35, 0, 22, 77, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('22-1340', '1kg', 71.52, 5, 0, 22, 78, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('23-1337', '100g', 106.04, 39, 0, 23, 79, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('23-1338', '250g', 84.56, 20, 0, 23, 80, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('23-1339', '500g', 83.36, 29, 0, 23, 81, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('23-1340', '1kg', 49.14, 42, 0, 23, 82, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('24-1337', '100g', 111.43, 50, 0, 24, 83, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('24-1338', '250g', 98.55, 44, 0, 24, 84, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('24-1339', '500g', 57.58, 31, 0, 24, 85, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('24-1340', '1kg', 48.75, 22, 0, 24, 86, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('25-1337', '100g', 74.06, 9, 0, 25, 87, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('25-1338', '250g', 47.58, 29, 0, 25, 88, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('25-1339', '500g', 45.11, 13, 0, 25, 89, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('25-1340', '1kg', 34.42, 6, 0, 25, 90, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('26-1337', '100g', 116.32, 33, 0, 26, 91, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('26-1338', '250g', 104.50, 16, 0, 26, 92, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('26-1339', '500g', 89.33, 48, 0, 26, 93, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('26-1340', '1kg', 66.30, 27, 0, 26, 94, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('27-1337', '100g', 116.63, 6, 0, 27, 95, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('27-1338', '250g', 114.38, 10, 0, 27, 96, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('27-1339', '500g', 108.78, 35, 0, 27, 97, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('27-1340', '1kg', 81.09, 23, 0, 27, 98, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('28-1337', '100g', 71.82, 12, 0, 28, 99, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('28-1338', '250g', 46.97, 9, 0, 28, 100, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('28-1339', '500g', 36.75, 46, 0, 28, 101, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('28-1340', '1kg', 20.98, 50, 0, 28, 102, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('29-1337', '100g', 97.83, 2, 0, 29, 103, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('29-1338', '250g', 94.03, 48, 0, 29, 104, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('29-1339', '500g', 74.62, 2, 0, 29, 105, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('29-1340', '1kg', 55.80, 34, 0, 29, 106, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('30-1337', '100g', 104.07, 31, 0, 30, 107, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('30-1338', '250g', 81.87, 29, 0, 30, 108, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('30-1339', '500g', 73.23, 1, 0, 30, 109, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('30-1340', '1kg', 58.81, 32, 0, 30, 110, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('31-1337', '100g', 0.00, 48, 0, 31, 111, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('31-1338', '250g', 0.00, 38, 0, 31, 112, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('31-1339', '500g', 0.00, 29, 0, 31, 113, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('32-1337', '100g', 0.00, 16, 0, 32, 114, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('32-1338', '250g', 0.00, 34, 0, 32, 115, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('32-1339', '500g', 0.00, 43, 0, 32, 116, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('33-1337', '100g', 0.00, 48, 0, 33, 117, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('33-1338', '250g', 0.00, 19, 0, 33, 118, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('33-1339', '500g', 0.00, 49, 0, 33, 119, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('34-1337', '100g', 0.00, 26, 0, 34, 120, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('34-1338', '250g', 0.00, 41, 0, 34, 121, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('34-1339', '500g', 0.00, 10, 0, 34, 122, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('35-1337', '100g', 0.00, 41, 0, 35, 123, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('35-1338', '250g', 0.00, 28, 0, 35, 124, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('35-1339', '500g', 0.00, 1, 0, 35, 125, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('36-1337', '100g', 0.00, 37, 0, 36, 126, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('36-1338', '250g', 0.00, 44, 0, 36, 127, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('36-1339', '500g', 0.00, 21, 0, 36, 128, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('37-1337', '100g', 0.00, 15, 0, 37, 129, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('37-1338', '250g', 0.00, 15, 0, 37, 130, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('37-1339', '500g', 0.00, 36, 0, 37, 131, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('38-1337', '100g', 0.00, 6, 0, 38, 132, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('38-1338', '250g', 0.00, 44, 0, 38, 133, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('38-1339', '500g', 0.00, 22, 0, 38, 134, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('39-1337', '100g', 0.00, 45, 0, 39, 135, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('39-1338', '250g', 0.00, 11, 0, 39, 136, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('39-1339', '500g', 0.00, 5, 0, 39, 137, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('40-1337', '100g', 0.00, 23, 0, 40, 138, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('40-1338', '250g', 0.00, 13, 0, 40, 139, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('40-1339', '500g', 0.00, 3, 0, 40, 140, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('41-94459', NULL, 0.00, 18, 0, 41, 141, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('42-19449', NULL, 0.00, 43, 0, 42, 142, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('43-91251', NULL, 0.00, 11, 0, 43, 143, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('44-28305', NULL, 0.00, 50, 0, 44, 144, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('45-76142', NULL, 0.00, 27, 0, 45, 145, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('46-65861', NULL, 0.00, 47, 0, 46, 146, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('47-88607', NULL, 0.00, 8, 0, 47, 147, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('48-71657', NULL, 0.00, 16, 0, 48, 148, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('49-13478', NULL, 0.00, 9, 0, 49, 149, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('50-78902', NULL, 0.00, 25, 0, 50, 150, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('51-1337', 'Soft', 0.00, 3, 0, 51, 151, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('51-1338', 'Hard', 0.00, 19, 0, 51, 152, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('52-1337', 'Soft', 0.00, 46, 0, 52, 153, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('52-1338', 'Hard', 0.00, 46, 0, 52, 154, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('53-1337', 'Soft', 0.00, 29, 0, 53, 155, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('53-1338', 'Hard', 0.00, 34, 0, 53, 156, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('54-1337', 'Soft', 0.00, 49, 0, 54, 157, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('54-1338', 'Hard', 0.00, 44, 0, 54, 158, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('55-1337', 'Soft', 0.00, 13, 0, 55, 159, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('55-1338', 'Hard', 0.00, 46, 0, 55, 160, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('56-1337', 'Soft', 0.00, 50, 0, 56, 161, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('56-1338', 'Hard', 0.00, 27, 0, 56, 162, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('57-1337', 'Soft', 0.00, 32, 0, 57, 163, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('57-1338', 'Hard', 0.00, 41, 0, 57, 164, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('58-1337', 'Soft', 0.00, 24, 0, 58, 165, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('58-1338', 'Hard', 0.00, 48, 0, 58, 166, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('59-1337', 'Soft', 0.00, 39, 0, 59, 167, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('59-1338', 'Hard', 0.00, 12, 0, 59, 168, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('60-1337', 'Soft', 0.00, 19, 0, 60, 169, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('60-1338', 'Hard', 0.00, 12, 0, 60, 170, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `public_menuitem`
--

CREATE TABLE `public_menuitem` (
  `title` varchar(255) NOT NULL,
  `order` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `collection_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `page_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `public_menuitem`
--

INSERT INTO `public_menuitem` (`title`, `order`, `url`, `category_id`, `collection_id`, `position`, `page_id`, `parent_id`, `id`, `created_at`, `updated_at`) VALUES
('Apparel', 0, NULL, 1, 0, 1, 0, 0, 1, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Accessories', 0, NULL, 2, 0, 1, 0, 0, 2, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Groceries', 0, NULL, 3, 0, 1, 0, 0, 3, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Coffees', 0, NULL, 4, 0, 0, 0, 3, 4, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Candies', 0, NULL, 5, 0, 0, 0, 3, 5, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Books', 0, NULL, 6, 0, 1, 0, 0, 6, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Collections', 0, NULL, 0, 0, 2, 0, 0, 7, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Summer collection', 0, NULL, 0, 1, 0, 0, 7, 8, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Winter sale', 0, NULL, 0, 2, 0, 0, 7, 9, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Saleor', 0, NULL, 0, 0, 2, 0, 0, 10, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('About', 0, NULL, 0, 0, 0, 1, 10, 11, '2024-06-23 16:28:21', '2024-06-23 16:28:21'),
('Style guide', 0, '/style', 0, 0, 0, 0, 10, 12, '2024-06-23 16:28:21', '2024-06-23 16:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `public_page`
--

CREATE TABLE `public_page` (
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `is_visible` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `public_page`
--

INSERT INTO `public_page` (`title`, `slug`, `content`, `is_visible`, `id`, `created_at`, `updated_at`) VALUES
('About', 'about', '<p style=\"text-align: start;\">This repository contains a Flask API for credit card fraud detection using a machine learning model. The project includes pre-trained models, data preprocessing, and an API for making predictions. Below, you\'ll find information on how to use this code for local development, the project structure, and an explanation of the machine learning model.</p><p style=\"text-align: start;\"><br></p><p> &nbsp; &nbsp;</p><h2></h2>', 1, 1, '2024-06-23 16:28:21', '2024-06-30 09:31:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_address`
--
ALTER TABLE `account_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `account_role`
--
ALTER TABLE `account_role`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `account_user`
--
ALTER TABLE `account_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `ix_account_user_open_id` (`open_id`),
  ADD KEY `ix_account_user_session_key` (`session_key`);

--
-- Indexes for table `account_user_role`
--
ALTER TABLE `account_user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkout_cart`
--
ALTER TABLE `checkout_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkout_cartline`
--
ALTER TABLE `checkout_cartline`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkout_shippingmethod`
--
ALTER TABLE `checkout_shippingmethod`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discount_sale`
--
ALTER TABLE `discount_sale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discount_sale_category`
--
ALTER TABLE `discount_sale_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discount_sale_product`
--
ALTER TABLE `discount_sale_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discount_voucher`
--
ALTER TABLE `discount_voucher`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `management_dashboard`
--
ALTER TABLE `management_dashboard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `management_setting`
--
ALTER TABLE `management_setting`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `order_event`
--
ALTER TABLE `order_event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_line`
--
ALTER TABLE `order_line`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_note`
--
ALTER TABLE `order_note`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_order`
--
ALTER TABLE `order_order`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- Indexes for table `order_payment`
--
ALTER TABLE `order_payment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payment_no` (`payment_no`);

--
-- Indexes for table `plugin_registry`
--
ALTER TABLE `plugin_registry`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `product_attribute`
--
ALTER TABLE `product_attribute`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_attribute_value`
--
ALTER TABLE `product_attribute_value`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_collection`
--
ALTER TABLE `product_collection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_collection_product`
--
ALTER TABLE `product_collection_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_image`
--
ALTER TABLE `product_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_product`
--
ALTER TABLE `product_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_type`
--
ALTER TABLE `product_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_type_attribute`
--
ALTER TABLE `product_type_attribute`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_variant`
--
ALTER TABLE `product_variant`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`);

--
-- Indexes for table `public_menuitem`
--
ALTER TABLE `public_menuitem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `public_page`
--
ALTER TABLE `public_page`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_address`
--
ALTER TABLE `account_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `account_role`
--
ALTER TABLE `account_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `account_user`
--
ALTER TABLE `account_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `account_user_role`
--
ALTER TABLE `account_user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `checkout_cart`
--
ALTER TABLE `checkout_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `checkout_cartline`
--
ALTER TABLE `checkout_cartline`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `checkout_shippingmethod`
--
ALTER TABLE `checkout_shippingmethod`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `discount_sale`
--
ALTER TABLE `discount_sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `discount_sale_category`
--
ALTER TABLE `discount_sale_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `discount_sale_product`
--
ALTER TABLE `discount_sale_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `discount_voucher`
--
ALTER TABLE `discount_voucher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `management_dashboard`
--
ALTER TABLE `management_dashboard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `order_event`
--
ALTER TABLE `order_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_line`
--
ALTER TABLE `order_line`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `order_note`
--
ALTER TABLE `order_note`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `order_order`
--
ALTER TABLE `order_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `order_payment`
--
ALTER TABLE `order_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `plugin_registry`
--
ALTER TABLE `plugin_registry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_attribute`
--
ALTER TABLE `product_attribute`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product_attribute_value`
--
ALTER TABLE `product_attribute_value`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product_collection`
--
ALTER TABLE `product_collection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product_collection_product`
--
ALTER TABLE `product_collection_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product_image`
--
ALTER TABLE `product_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `product_product`
--
ALTER TABLE `product_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `product_type`
--
ALTER TABLE `product_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product_type_attribute`
--
ALTER TABLE `product_type_attribute`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product_variant`
--
ALTER TABLE `product_variant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;

--
-- AUTO_INCREMENT for table `public_menuitem`
--
ALTER TABLE `public_menuitem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `public_page`
--
ALTER TABLE `public_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
