import time
from datetime import datetime
import csv
import ipinfo
from flask import (
    Blueprint,
    abort,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from flask_babel import lazy_gettext
from flask_login import current_user, login_required
from pluggy import HookimplMarker
import stripe

from flaskshop.account.forms import StripeForm
from flaskshop.constant import OrderStatusKinds, PaymentStatusKinds, ShipStatusKinds
from flaskshop.extensions import csrf_protect
from .payment import zhifubao

from .models import Order, OrderPayment

impl = HookimplMarker("flaskshop")

stripe.api_key = "sk_test_51IsSLMHFOK9hcAhfEikD9oKNtsC3gU3714ICRsiHMx4ZEBgXCpXFXRwEIbDP1iTBCGn3cRPjgClxM9sJFZH4GnC600twJO1zge"

@login_required
def index():
    return redirect(url_for("account.index"))


@login_required
def show(token):
    order = Order.query.filter_by(token=token).first()
    if not order.is_self_order:
        abort(403, lazy_gettext("This is not your order!"))
    return render_template("orders/details.html", order=order)


def create_payment(token, payment_method):
    order = Order.query.filter_by(token=token).first()
    if order.status != OrderStatusKinds.unfulfilled.value:
        abort(403, lazy_gettext("This Order Can Not Pay"))
    payment_no = str(int(time.time())) + str(current_user.id)
    customer_ip_address = request.headers.get("X-Forwarded-For", request.remote_addr)
    payment = OrderPayment.query.filter_by(order_id=order.id).first()
    if payment:
        payment.update(
            payment_method=payment_method,
            payment_no=payment_no,
            customer_ip_address=customer_ip_address,
        )
    else:
        payment = OrderPayment.create(
            order_id=order.id,
            payment_method=payment_method,
            payment_no=payment_no,
            status=PaymentStatusKinds.waiting.value,
            total=order.total,
            customer_ip_address=customer_ip_address,
        )
    if payment_method == "alipay":
        
        
        redirect_url = zhifubao.send_order(order.token, payment_no, order.total)
        payment.redirect_url = redirect_url
        
    return payment


@login_required
def ali_pay(token):
    # payment = create_payment(token, "alipay")
    order = Order.query.filter_by(token=token).first()
    form = StripeForm()
    return render_template("checkout/payment.html",order=order,form=form)

    # return redirect(payment.redirect_url)
@login_required
def stripe_pay(token):
     data = request.form.to_dict()
     order = Order.query.filter_by(token=token).first()
     amount = order.total
      # fraud detection using previous data stored and location
     ls = []
     access_token = 'd93b8e63158f6e'     # access token from ipinfo.io
     handler = ipinfo.getHandler(access_token)
     details = handler.getDetails()      # getting all the details about location
     # this file can be downloaded from Stripe Admin account
     with open(r'C:\\Transaction Fraud Detection\\Online Transaction Fraud Detection\\flaskshop\\unified_payments.csv', 'r') as file:
                reader = csv.DictReader(file)
                sum = 0
                for row in reader:
                    amt = float(dict(row)["Amount"])
                    ls.append(amt)
      # assuming that user will not go beyond the 1.5 times of highest payment he/she done in past
     limit = int(1.5 * max(ls) * 100)
     print(limit)
     print(amount)
     print(details.country)
     if(amount > limit):             # checking if user is going beyond the defined limit User not allowed for this payment.
            err_msg = lazy_gettext("User not allowed for this payment beacuse it's a fraud transcation" )
            flash(err_msg, "warning")
            return redirect('/')
     elif(details.country != 'IN'):  # checking if user is in India or not User not allowed for this payment.
            err_msg = lazy_gettext("User not allowed for this payment beacuse it's a fraud transcation")
            flash(err_msg, "warning")
            return redirect('/')
     else:
        payment = create_payment(token, "testpay")                     
        payment.pay_success(paid_at=datetime.now())
        return redirect(url_for("order.payment_success"))
  

@csrf_protect.exempt
def ali_notify():
    data = request.form.to_dict()
    success = zhifubao.verify_order(data)
    if success:
        order_payment = OrderPayment.query.filter_by(
            payment_no=data["out_trade_no"]
        ).first()
        order_payment.pay_success(paid_at=data["gmt_payment"])
        return "SUCCESS"
    return "ERROR HAPPEND"


@login_required
def test_pay_flow(token):
    payment = create_payment(token, "testpay")
    payment.pay_success(paid_at=datetime.now())
    return redirect(url_for("order.payment_success"))


@login_required
def payment_success():
    payment_no = request.args.get("out_trade_no")
    if payment_no:
        res = zhifubao.query_order(payment_no)
        if res["code"] == "10000":
            order_payment = OrderPayment.query.filter_by(
                payment_no=res["out_trade_no"]
            ).first()
            order_payment.pay_success(paid_at=res["send_pay_date"])
        else:
            print(res["msg"])

    return render_template("orders/checkout_success.html")


@login_required
def cancel_order(token):
    order = Order.query.filter_by(token=token).first()
    if not order.is_self_order:
        abort(403, "This is not your order!")
    order.cancel()
    return render_template("orders/details.html", order=order)


@login_required
def receive(token):
    order = Order.query.filter_by(token=token).first()
    order.update(
        status=OrderStatusKinds.completed.value,
        ship_status=ShipStatusKinds.received.value,
    )
    return render_template("orders/details.html", order=order)


@impl
def flaskshop_load_blueprints(app):
    bp = Blueprint("order", __name__)
    bp.add_url_rule("/", view_func=index)
    bp.add_url_rule("/<string:token>", view_func=show)
    bp.add_url_rule("/pay/<string:token>/alipay", view_func=ali_pay, methods=["GET"])
    bp.add_url_rule("/pay/<string:token>/alipay", view_func=stripe_pay, methods=["POST"])
    bp.add_url_rule("/alipay/notify", view_func=ali_notify, methods=["POST", "HEAD"])
    bp.add_url_rule("/pay/<string:token>/testpay", view_func=test_pay_flow)
    bp.add_url_rule("/payment_success", view_func=payment_success)
    bp.add_url_rule("/cancel/<string:token>", view_func=cancel_order)
    bp.add_url_rule("/receive/<string:token>", view_func=receive)
    app.register_blueprint(bp, url_prefix="/orders")
